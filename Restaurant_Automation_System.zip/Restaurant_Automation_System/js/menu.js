/* Shared menu: Owner/Chef edit it, Customer reads it, all via DB('menu'). FUTURE API: /api/menu */
const Menu={q:'',cat:'All',
 pic:m=>/^https?:/.test(m.img)?`<img src="${esc(m.img)}" alt="">`:esc(m.img),
 cards(){const t=this.q.toLowerCase();return DB.get('menu').filter(m=>(this.cat=='All'||m.cat==this.cat)&&m.name.toLowerCase().includes(t)).map(m=>`<div class=card><div class=img>${this.pic(m)}</div><b>${esc(m.name)}</b> <small>${esc(m.cat)}</small><p>${esc(m.desc)}</p><b>${money(m.price)}</b> ${m.avail?btn('Add to cart',`Cart.add('${m.id}')`):'<span class=bad>Unavailable</span>'}</div>`).join('')||'<p>No food items match.</p>'},
 list(){$('#list').innerHTML=this.cards()},
 view(){this.q='';this.cat='All';return `<h3>Menu</h3><div class=bar><input placeholder="Search food" oninput="Menu.q=this.value;Menu.list()"><select onchange="Menu.cat=this.value;Menu.list()">${['All',...DB.get('cats')].map(c=>`<option>${esc(c)}</option>`).join('')}</select></div><div id=list class=grid>${this.cards()}</div>`},
 manage(){return '<h3>Menu management</h3>'+btn('+ Add item','Menu.edit()')+btn('+ Category','Menu.addCat()','alt')+tbl(['Item','Category','Price','Status',''],DB.get('menu').map(m=>[(/^https?:/.test(m.img)?'':esc(m.img))+' '+esc(m.name),esc(m.cat),money(m.price),m.avail?'Available':'<span class=bad>Unavailable</span>',btn('Edit',`Menu.edit('${m.id}')`)+btn(m.avail?'Mark unavailable':'Mark available',`Menu.tog('${m.id}')`,'alt')+btn('Delete',`Menu.rm('${m.id}')`,'danger')]))},
 edit(id){const m=id?DB.find('menu',id):{name:'',cat:DB.get('cats')[0],price:'',desc:'',img:'🍽️'};
  form(id?'Edit food item':'Add food item',[{n:'name',l:'Name',v:m.name},{n:'cat',l:'Category',v:m.cat,o:DB.get('cats')},{n:'price',l:'Price (₹)',t:'number',v:m.price},{n:'desc',l:'Description',v:m.desc},{n:'img',l:'Image (emoji or image URL)',v:m.img}],o=>{
   o.price=+o.price;if(!o.name.trim()||!(o.price>=0))return toast('Enter a name and a valid price');
   if(id){DB.upd('menu',id,o);DB.log(me(),'Edited menu item '+o.name,m.price,o.price)}else{DB.add('menu',{...o,avail:true});DB.log(me(),'Added menu item '+o.name,'',o.price)}
   refresh();toast('Menu saved')})},
 tog(id){const m=DB.find('menu',id);DB.upd('menu',id,{avail:!m.avail});DB.log(me(),'Availability of '+m.name,m.avail,!m.avail);refresh()},
 rm(id){const m=DB.find('menu',id);if(confirm('Delete '+m.name+'?')){DB.del('menu',id);DB.log(me(),'Deleted menu item '+m.name);refresh()}},
 addCat(){const c=(prompt('New category name')||'').trim();if(c&&!DB.get('cats').includes(c)){DB.set('cats',[...DB.get('cats'),c]);refresh()}}
};
