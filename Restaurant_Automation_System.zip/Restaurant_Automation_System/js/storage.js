/* TEMPORARY frontend storage (localStorage). DB is the single seam for a future backend:
   replace get/set/add/upd/del/find with fetch() calls to a REST API and the UI code stays unchanged. */
const DB={
 get(n,d=[]){try{const v=localStorage.getItem('ras_'+n);return v?JSON.parse(v):d}catch(e){return d}},
 set(n,v){localStorage.setItem('ras_'+n,JSON.stringify(v))},   // FUTURE API: PUT /api/<n>
 id:()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6),
 find(n,id){return this.get(n).find(x=>x.id==id)},               // FUTURE API: GET /api/<n>/:id
 add(n,o){o.id=o.id||this.id();o.t=o.t||Date.now();const a=this.get(n);a.push(o);this.set(n,a);return o}, // POST
 upd(n,id,p){const a=this.get(n),o=a.find(x=>x.id==id);if(o)Object.assign(o,p);this.set(n,a);return o},   // PATCH
 del(n,id){this.set(n,this.get(n).filter(x=>x.id!=id))},         // DELETE
 log(u,act,a='',b=''){this.add('logs',{user:u.name,role:u.role,act,a,b})},
 seed(force){
  if(!force&&localStorage.ras_users)return;
  Object.keys(localStorage).filter(k=>k.startsWith('ras_')).forEach(k=>localStorage.removeItem(k));
  // Demo passwords are plain text ONLY because this is temporary demo data. A real backend must hash them.
  this.set('users',[['owner','Owner'],['chef','Head Chef'],['supplier','Fresh Supplies'],['customer','Demo Customer']].map(([r,n])=>({id:r+'1',role:r,name:n,email:r+'@restaurant.com',pass:r+'123',active:true,t:Date.now()})));
  this.set('cats',['Starters','Main Course','Desserts','Beverages']);
  this.set('menu',[['Paneer Tikka','Starters',220,'Smoky grilled cottage cheese','🧆'],['Veg Spring Rolls','Starters',150,'Crispy rolls with vegetable filling','🥟'],['Butter Chicken','Main Course',340,'Chicken in creamy tomato gravy','🍛'],['Veg Biryani','Main Course',260,'Basmati rice with vegetables','🍚'],['Margherita Pizza','Main Course',300,'Mozzarella and basil','🍕'],['Gulab Jamun','Desserts',90,'Warm syrup-soaked dumplings','🍮'],['Masala Chai','Beverages',40,'Spiced milk tea','☕'],['Mango Lassi','Beverages',80,'Chilled sweet yogurt drink','🥭']].map(([name,cat,price,desc,img],i)=>({id:'m'+i,name,cat,price,desc,img,avail:true})));
  const ig=[['Paneer','kg',10,4,320],['Rice','kg',25,10,70],['Chicken','kg',3,5,210],['Cooking Oil','L',12,5,140],['Milk','L',15,6,60],['Tomato','kg',8,4,40]];
  this.set('ing',ig.map(([name,unit,qty,min],i)=>({id:'i'+i,name,unit,qty,min})));
  this.set('catalog',ig.map(([name,unit,,,price],i)=>({id:'c'+i,name,unit,price})));
  ['orders','reqs','invoices','notifs','logs','feedback','expenses','stock'].forEach(k=>this.set(k,[]));
 }};
DB.seed();
