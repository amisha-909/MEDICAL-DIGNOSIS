const Billing={TAX:.05,
 calc(sub){const disc=sub>=1000?sub*.1:0,tax=(sub-disc)*this.TAX;return{sub,disc,tax,total:sub-disc+tax}},
 html(p){return `<p>Subtotal ${money(p.sub)}<br>Discount (10% above ₹1000) −${money(p.disc)}<br>GST 5% ${money(p.tax)}<br><b>Total ${money(p.total)}</b></p>`},
 print(id){const o=DB.find('orders',id),w=open('','_blank');
  w.document.write(`<title>${o.bill}</title><body style="font-family:sans-serif;max-width:420px;margin:2em auto"><h2>RESTAURANT AUTOMATION SYSTEM</h2><p>${o.bill} · ${o.no}<br>${esc(o.custName)} · ${when(o.t)} · ${o.type}</p><table width=100%>${o.items.map(i=>`<tr><td>${esc(i.name)} × ${i.qty}</td><td align=right>${money(i.price*i.qty)}</td></tr>`).join('')}</table>${this.html(o.pay)}<script>print()<\/script>`);w.document.close()}
};
