/* Owner overview, reports, expenses, employees. FUTURE API: /api/reports/*, /api/users */
const Rep={
 sales(d){const f=Date.now()-d*864e5;return DB.get('orders').filter(o=>o.status!='Cancelled'&&o.t>=f).reduce((s,o)=>s+o.pay.total,0)},
 over(){const o=DB.get('orders'),ok=o.filter(x=>x.status!='Cancelled'),day=new Date().setHours(0,0,0,0),sum=a=>a.reduce((s,x)=>s+x.pay.total,0);
  const c=[['Total orders',o.length],["Today's sales",money(sum(ok.filter(x=>x.t>=day)))],['Total revenue',money(sum(ok))],['Pending orders',o.filter(x=>ST.slice(0,4).includes(x.status)).length],['Completed orders',o.filter(x=>x.status=='Completed').length],['Customers',DB.get('users').filter(x=>x.role=='customer').length],['Menu items',DB.get('menu').length],['Available ingredients',DB.get('ing').filter(i=>i.qty>0).length],['Low-stock alerts',Inv.low().length],['Pending supplier bills',DB.get('invoices').filter(v=>['Pending Approval','Approved'].includes(v.status)).length]];
  return '<h3>Overview</h3><div class=grid>'+c.map(x=>`<div class="card stat"><small>${x[0]}</small><b>${x[1]}</b></div>`).join('')+'</div>'+btn('Reset demo data','Rep.reset()','danger')},
 reset(){if(confirm('Reset ALL data back to the demo data?')){DB.seed(true);sessionStorage.clear();location.href='login.html'}},
 rep(){const ok=DB.get('orders').filter(x=>x.status!='Cancelled'),best={};ok.forEach(o=>o.items.forEach(i=>best[i.name]=(best[i.name]||0)+i.qty));
  const ex=DB.get('expenses'),te=ex.reduce((s,e)=>s+e.amt,0),rev=ok.reduce((s,o)=>s+o.pay.total,0);
  return '<h3>Reports</h3><div class=grid>'+[['Daily sales',this.sales(1)],['Weekly sales',this.sales(7)],['Monthly sales',this.sales(30)],['Total expenses',te],['Estimated profit',rev-te]].map(x=>`<div class="card stat"><small>${x[0]}</small><b>${money(x[1])}</b></div>`).join('')+'</div>'+
  '<h4>Best-selling items</h4>'+tbl(['Item','Sold'],Object.entries(best).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([n,c])=>[esc(n),c]))+
  '<h4>Expenses & ingredient purchases</h4>'+btn('+ Expense','Rep.exp()')+tbl(['Date','Category','Amount','Note'],ex.slice().reverse().map(e=>[when(e.t),esc(e.cat),money(e.amt),esc(e.note||'')]))+
  '<h4>Customer feedback</h4>'+tbl(['Customer','Rating','Review'],DB.get('feedback').map(f=>[esc(f.who),'★'.repeat(f.stars),esc(f.text)]))+
  '<h4>Activity history</h4>'+tbl(['When','User','Action','Previous','New'],DB.get('logs').slice(-15).reverse().map(l=>[when(l.t),esc(l.user+' ('+l.role+')'),esc(l.act),esc(l.a),esc(l.b)]))},
 exp(){form('Add expense',[{n:'cat',l:'Category',o:['Salary','Utilities','Rent','Maintenance','Other']},{n:'amt',l:'Amount (₹)',t:'number'},{n:'note',l:'Note'}],o=>{o.amt=+o.amt;if(!(o.amt>0))return toast('Enter an amount');DB.add('expenses',o);DB.log(me(),'Added expense '+o.cat,'',o.amt);refresh()})},
 staff(){return '<h3>Chefs & suppliers</h3>'+btn('+ Chef',`Rep.emp('chef')`)+btn('+ Supplier',`Rep.emp('supplier')`,'alt')+tbl(['Name','Role','Email','Status',''],DB.get('users').filter(u=>u.role=='chef'||u.role=='supplier').map(u=>[esc(u.name),u.role,esc(u.email),u.active?'Active':'<span class=bad>Inactive</span>',btn('Edit',`Rep.emp('${u.role}','${u.id}')`)+btn(u.active?'Deactivate':'Activate',`Rep.act('${u.id}')`,'alt')]))},
 emp(role,id){const u=id?DB.find('users',id):{name:'',email:'',pass:''};form((id?'Edit ':'New ')+role,[{n:'name',l:'Name',v:u.name},{n:'email',l:'Email',t:'email',v:u.email},{n:'pass',l:'Password',v:u.pass}],o=>{
  o.email=o.email.trim().toLowerCase();if(!o.name||!o.email||!o.pass)return toast('All fields are required');if(DB.get('users').some(x=>x.email==o.email&&x.id!=id))return toast('That email is already used');
  id?DB.upd('users',id,o):DB.add('users',{...o,role,active:true});DB.log(me(),(id?'Edited ':'Created ')+role+' '+o.name);refresh()})},
 act(id){const u=DB.find('users',id);DB.upd('users',id,{active:!u.active});DB.log(me(),'Account of '+u.name,u.active,!u.active);refresh()}
};
