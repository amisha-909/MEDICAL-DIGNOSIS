/* to = a role name ('owner','chef','supplier') or a user id. FUTURE API: GET/POST /api/notifications (or websocket push). */
const Notif={
 send(to,m){DB.add('notifs',{to,m,read:false})},
 mine(u){return DB.get('notifs').filter(n=>n.to==u.id||(n.to==u.role&&u.role!='customer')).sort((a,b)=>b.t-a.t)},
 view(u){const l=this.mine(u);DB.set('notifs',DB.get('notifs').map(n=>(n.to==u.id||(n.to==u.role&&u.role!='customer'))?{...n,read:true}:n));
  return '<h3>Notifications</h3>'+tbl(['When','Message'],l.map(n=>[when(n.t),(n.read?'':'<b>NEW</b> ')+esc(n.m)]))}
};
