/* Official stock is changed ONLY by the Owner (approving a delivery), Chef usage/wastage, or manual edits.
   Supplier only creates invoices. FUTURE API: /api/ingredients, /api/purchase-requests, /api/invoices */
const Inv={
 low(){return DB.get('ing').filter(i=>i.qty<=i.min)},
 adjust(id,d,why){const i=DB.find('ing',id),q=Math.max(0,+(i.qty+d).toFixed(3));DB.upd('ing',id,{qty:q});DB.add('stock',{ing:i.name,d:+d,why,by:me().name});
  if(q<=i.min&&i.qty>i.min){Notif.send('owner','Low stock: '+i.name);Notif.send('chef','Low stock: '+i.name)}},
 view(u){const ow=u.role=='owner',l=this.low();
  return '<h3>Inventory</h3>'+(l.length?`<div class=warn>⚠ Low stock: ${l.map(i=>esc(i.name)).join(', ')}</div>`:'')+(ow?btn('+ Ingredient','Inv.edit()')+btn('+ Purchase request','Inv.req()','alt'):'')+
  tbl(['Ingredient','Stock','Minimum','Unit',''],DB.get('ing').map(i=>[esc(i.name),`<span class="${i.qty<=i.min?'bad':''}">${i.qty}</span>`,i.min,esc(i.unit),ow?btn('Edit',`Inv.edit('${i.id}')`)+btn('Set stock',`Inv.set('${i.id}')`,'alt'):btn('Record use',`Inv.use('${i.id}','Consumption')`)+btn('Wastage',`Inv.use('${i.id}','Wastage')`,'alt')+btn('Report unavailable',`Inv.out('${i.id}')`,'danger')]))+
  '<h4>Stock history</h4>'+tbl(['When','Ingredient','Change','Reason','By'],DB.get('stock').slice(-12).reverse().map(s=>[when(s.t),esc(s.ing),s.d,esc(s.why),esc(s.by)]))},
 edit(id){const i=id?DB.find('ing',id):{name:'',unit:'kg',min:5};form(id?'Edit ingredient':'Add ingredient',[{n:'name',l:'Name',v:i.name},{n:'unit',l:'Unit',v:i.unit},{n:'min',l:'Minimum stock level',t:'number',v:i.min},...(id?[]:[{n:'qty',l:'Opening stock',t:'number',v:0}])],o=>{
  o.min=+o.min;if(!o.name)return toast('Enter a name');if(id)DB.upd('ing',id,o);else DB.add('ing',{...o,qty:+o.qty||0});DB.log(me(),(id?'Edited':'Added')+' ingredient '+o.name);refresh()})},
 set(id){const i=DB.find('ing',id);form('Set stock: '+i.name,[{n:'q',l:'New quantity',t:'number',v:i.qty}],o=>{Inv.adjust(id,+o.q-i.qty,'Manual update');DB.log(me(),'Stock of '+i.name,i.qty,o.q);refresh()})},
 use(id,why){const i=DB.find('ing',id);form(why+': '+i.name,[{n:'q',l:'Quantity ('+i.unit+')',t:'number'}],o=>{if(+o.q>0){Inv.adjust(id,-o.q,why);refresh()}})},
 out(id){Notif.send('owner','Chef reports ingredient unavailable: '+DB.find('ing',id).name);toast('Owner notified')},
 req(){form('Purchase request',[{n:'ing',l:'Ingredient',o:DB.get('catalog').map(c=>c.name)},{n:'qty',l:'Quantity',t:'number'}],o=>{if(!(+o.qty>0))return toast('Enter a quantity');DB.add('reqs',{ing:o.ing,qty:+o.qty,status:'Requested'});Notif.send('supplier','New purchase request: '+o.ing);refresh()})},
 owner(){return '<h3>Purchase requests</h3>'+btn('+ New request','Inv.req()')+tbl(['Ingredient','Qty','Status'],DB.get('reqs').slice().reverse().map(r=>[esc(r.ing),r.qty,r.status]))+
  '<h3>Supplier invoices</h3>'+tbl(['Invoice','Item','Delivered','Total','Status',''],DB.get('invoices').slice().reverse().map(v=>[v.no,esc(v.ing),v.qty,money(v.total),v.status,v.status=='Pending Approval'?btn('Verify & add to stock',`Inv.appr('${v.id}',1)`)+btn('Reject',`Inv.appr('${v.id}',0)`,'danger'):v.status=='Approved'?btn('Mark paid',`Inv.pay('${v.id}')`):'']))},
 appr(id,ok){const v=DB.find('invoices',id);DB.upd('invoices',id,{status:ok?'Approved':'Rejected'});
  if(ok){let i=DB.get('ing').find(x=>x.name==v.ing);if(!i)i=DB.add('ing',{name:v.ing,unit:v.unit,qty:0,min:5});Inv.adjust(i.id,v.qty,'Delivery '+v.no)}
  Notif.send('supplier',`Invoice ${v.no} ${ok?'approved':'rejected'}`);DB.log(me(),'Invoice '+v.no,v.status,ok?'Approved':'Rejected');refresh()},
 pay(id){const v=DB.find('invoices',id);DB.upd('invoices',id,{status:'Paid'});DB.add('expenses',{cat:'Ingredient purchase',amt:v.total,note:v.no});Notif.send('supplier',`Invoice ${v.no} paid`);DB.log(me(),'Paid invoice '+v.no);refresh()},
 cat(){return '<h3>Ingredient catalogue</h3>'+btn('+ Add ingredient','Inv.cedit()')+tbl(['Name','Unit','Price',''],DB.get('catalog').map(c=>[esc(c.name),esc(c.unit),money(c.price),btn('Edit',`Inv.cedit('${c.id}')`)]))},
 cedit(id){const c=id?DB.find('catalog',id):{name:'',unit:'kg',price:''};form('Catalogue item',[{n:'name',l:'Name',v:c.name},{n:'unit',l:'Unit',v:c.unit},{n:'price',l:'Price per unit (₹)',t:'number',v:c.price}],o=>{o.price=+o.price;if(!o.name)return toast('Enter a name');id?DB.upd('catalog',id,o):DB.add('catalog',o);refresh()})},
 reqs(){return '<h3>Purchase requests</h3>'+tbl(['Ingredient','Qty','Status',''],DB.get('reqs').slice().reverse().map(r=>[esc(r.ing),r.qty,r.status,r.status=='Requested'?btn('Accept',`Inv.rq('${r.id}','Accepted')`)+btn('Reject',`Inv.rq('${r.id}','Rejected')`,'danger'):r.status=='Accepted'?btn('Deliver & invoice',`Inv.deliver('${r.id}')`):'']))},
 rq(id,s){DB.upd('reqs',id,{status:s});Notif.send('owner',`Request for ${DB.find('reqs',id).ing} ${s.toLowerCase()} by supplier`);refresh()},
 deliver(id){const r=DB.find('reqs',id),c=DB.get('catalog').find(x=>x.name==r.ing)||{price:'',unit:''};
  form('Delivery & invoice: '+r.ing,[{n:'qty',l:'Delivered quantity',t:'number',v:r.qty},{n:'price',l:'Unit price (₹)',t:'number',v:c.price}],o=>{const q=+o.qty,p=+o.price;if(!(q>0&&p>=0))return toast('Enter quantity and price');
   DB.add('invoices',{no:'INV-'+(DB.get('invoices').length+1001),req:id,ing:r.ing,unit:c.unit,qty:q,price:p,total:q*p,status:'Pending Approval'});DB.upd('reqs',id,{status:'Delivered'});Notif.send('owner','Delivery and invoice submitted: '+r.ing);refresh()})},
 invs(){const v=DB.get('invoices').slice().reverse();return '<h3>My invoices</h3>'+tbl(['Invoice','Item','Qty','Unit price','Total (auto)','Status'],v.map(x=>[x.no,esc(x.ing),x.qty,money(x.price),money(x.total),x.status]))+`<p>Pending payments: <b>${money(v.filter(x=>x.status=='Approved').reduce((s,x)=>s+x.total,0))}</b></p>`}
};
