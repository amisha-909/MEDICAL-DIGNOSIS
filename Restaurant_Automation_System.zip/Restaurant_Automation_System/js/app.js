/* Shared UI helpers + dashboard shell. Every dashboard page only loads the modules and this file. */
const $=s=>document.querySelector(s);
const money=n=>'₹'+(+n||0).toFixed(2);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
const when=t=>new Date(t).toLocaleString();
const me=()=>Auth.cur();
const btn=(l,fn,c='')=>`<button class="${c}" onclick="${fn}">${l}</button>`;
function toast(m){const d=document.createElement('div');d.className='toast';d.textContent=m;document.documentElement.append(d);setTimeout(()=>d.remove(),2200)}
function tbl(h,r){return `<div class=scroll><table><tr>${h.map(x=>`<th>${x}</th>`).join('')}</tr>${r.length?r.map(x=>`<tr>${x.map(c=>`<td>${c}</td>`).join('')}</tr>`).join(''):`<tr><td colspan=${h.length}>Nothing here yet.</td></tr>`}</table></div>`}
function form(t,f,cb){const d=document.createElement('dialog');
 d.innerHTML=`<form method=dialog><h3>${t}</h3>${f.map(x=>`<label>${x.l}${x.o?`<select name=${x.n}>${x.o.map(o=>`<option ${o==x.v?'selected':''}>${esc(o)}</option>`).join('')}</select>`:`<input name=${x.n} type=${x.t||'text'} step=any value="${esc(x.v??'')}">`}</label>`).join('')}<button value=ok>Save</button><button value=x class=alt formnovalidate>Cancel</button></form>`;
 document.body.append(d);d.showModal();d.onclose=()=>{if(d.returnValue=='ok'){const o={};new FormData(d.querySelector('form')).forEach((v,k)=>o[k]=v);cb(o)}d.remove()}}

const TABS={
 customer:[['menu','Menu',()=>Menu.view()],['cart','Cart',()=>Cart.view()],['orders','My orders',u=>Orders.mine(u)]],
 owner:[['ov','Overview',()=>Rep.over()],['ord','Orders',u=>Orders.staff(u)],['menu','Menu',()=>Menu.manage()],['inv','Inventory',u=>Inv.view(u)],['sup','Suppliers',()=>Inv.owner()],['emp','Employees',()=>Rep.staff()],['rep','Reports',()=>Rep.rep()]],
 chef:[['ord','Orders',u=>Orders.staff(u)],['menu','Menu',()=>Menu.manage()],['inv','Ingredients',u=>Inv.view(u)]],
 supplier:[['cat','Catalogue',()=>Inv.cat()],['req','Requests',()=>Inv.reqs()],['inv','Invoices',()=>Inv.invs()]]};
function boot(){
 const role=document.body.dataset.role,tabs=TABS[role];let cur=sessionStorage.ras_tab;
 const draw=()=>{const u=Auth.guard(role);if(!u)return;if(cur!='notif'&&!tabs.some(t=>t[0]==cur))cur=tabs[0][0];
  const h=cur=='notif'?Notif.view(u):tabs.find(t=>t[0]==cur)[2](u),n=Notif.mine(u).filter(x=>!x.read).length;
  document.body.innerHTML=`<aside><h2>RESTAURANT AUTOMATION SYSTEM</h2>${tabs.map(t=>`<a class="${t[0]==cur?'on':''}" onclick="go('${t[0]}')">${t[1]}</a>`).join('')}</aside><main><header><b>${role[0].toUpperCase()+role.slice(1)} · ${esc(u.name)}</b><span><a onclick="go('notif')">🔔 Notifications (${n})</a><button class=alt onclick="Auth.logout()">Logout</button></span></header><section id=v>${h}</section></main>`};
 window.go=t=>{cur=sessionStorage.ras_tab=t;draw()};window.refresh=draw;
 addEventListener('storage',draw);   // live sync between browser tabs
 draw();
}
boot();
