/* Session lives in sessionStorage so each browser tab can be a different role (handy for testing). FUTURE API: POST /api/login, token instead. */
const Auth={
 cur(){try{return DB.find('users',JSON.parse(sessionStorage.ras_user).id)||null}catch(e){return null}},
 guard(role){const u=this.cur();if(!u||u.role!=role||!u.active){location.href='login.html';return null}return u},
 login(e){e.preventDefault();const f=e.target,em=f.email.value.trim().toLowerCase(),m=document.getElementById('msg'),u=DB.get('users').find(x=>x.email==em&&x.pass==f.pass.value);
  if(!u)return m.textContent='Invalid email or password';if(!u.active)return m.textContent='This account is deactivated';
  sessionStorage.ras_user=JSON.stringify({id:u.id});location.href=u.role+'.html'},
 reg(e){e.preventDefault();const f=e.target,em=f.email.value.trim().toLowerCase(),m=document.getElementById('msg');
  if(DB.get('users').some(x=>x.email==em))return m.textContent='That email is already registered';
  const u=DB.add('users',{role:'customer',name:f.uname.value.trim(),email:em,pass:f.pass.value,active:true});
  sessionStorage.ras_user=JSON.stringify({id:u.id});location.href='customer.html'},
 logout(){sessionStorage.clear();location.href='login.html'},
 fill(r){const f=document.getElementById('lf');f.email.value=r+'@restaurant.com';f.pass.value=r+'123'}
};
