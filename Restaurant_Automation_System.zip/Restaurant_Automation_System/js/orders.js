/* Cart + orders. FUTURE API: /api/cart, /api/orders (status change = PATCH /api/orders/:id). */
const ST=['Order Placed','Accepted','Preparing','Ready','Out for Delivery','Completed','Cancelled'];
const itemsTxt=o=>o.items.map(i=>`${esc(i.name)} ×${i.qty}`).join(', ')+(o.note?`<br><i>“${esc(o.note)}”</i>`:'');
const Cart={k:()=>'cart_'+me().id,
 get(){return DB.get(this.k(),{})},
 add(id){const c=this.get();c[id]=(c[id]||0)+1;DB.set(this.k(),c);toast('Added to cart')},
 chg(id,d){const c=this.get();c[id]=(c[id]||0)+d;if(c[id]<=0)delete c[id];DB.set(this.k(),c);refresh()},
 view(){const r=Object.entries(this.get()).map(([id,q])=>({m:DB.find('menu',id),q})).filter(x=>x.m),p=Billing.calc(r.reduce((s,x)=>s+x.m.price*x.q,0));
  return '<h3>Your cart</h3>'+tbl(['Item','Price','Qty','Total',''],r.map(({m,q})=>[esc(m.name)+(m.avail?'':' <span class=bad>unavailable</span>'),money(m.price),btn('−',`Cart.chg('${m.id}',-1)`)+q+btn('+',`Cart.chg('${m.id}',1)`),money(m.price*q),btn('Remove',`Cart.chg('${m.id}',-999)`,'danger')]))+
  `<div class=card><label>Order type<select id=ot><option>Dine-in<option>Takeaway<option>Delivery</select></label><label>Special cooking instructions<textarea id=nt></textarea></label>${Billing.html(p)}${btn('Place order',`Orders.place($('#ot').value,$('#nt').value)`)}</div>`}
};
const Orders={
 place(type,note){const u=me(),e=Object.entries(Cart.get()).map(([id,q])=>[DB.find('menu',id),q]);
  if(!e.length)return toast('Your cart is empty');if(e.some(([m])=>!m||!m.avail))return toast('Remove unavailable items first');
  const items=e.map(([m,q])=>({id:m.id,name:m.name,price:m.price,qty:q})),pay=Billing.calc(items.reduce((s,i)=>s+i.price*i.qty,0)),n=DB.get('orders').length+1001;
  const o=DB.add('orders',{no:'ORD-'+n,bill:'BILL-'+n,cust:u.id,custName:u.name,items,type,note,status:ST[0],chef:null,pay});
  DB.set(Cart.k(),{});Notif.send('owner','New order '+o.no+' from '+u.name);Notif.send('chef','New order '+o.no);DB.log(u,'Placed order '+o.no,'',money(pay.total));go('orders');toast('Order '+o.no+' placed')},
 set(id,s){const u=me(),o=DB.find('orders',id),m=`Order ${o.no}: ${s}`;
  DB.upd('orders',id,{status:s,...(u.role=='chef'&&!o.chef?{chef:u.id}:{})});DB.log(u,'Order '+o.no+' status',o.status,s);
  if(u.role!='customer')Notif.send(o.cust,m);if(u.role!='owner')Notif.send('owner',m);if(u.role!='chef')Notif.send('chef',m);refresh()},
 cancel(id){if(confirm('Cancel this order?'))this.set(id,'Cancelled')},
 assign(id,c){DB.upd('orders',id,{chef:c||null});if(c)Notif.send(c,'An order was assigned to you');refresh()},
 rate(id){form('Rate your order',[{n:'stars',l:'Rating (1-5)',o:['5','4','3','2','1']},{n:'text',l:'Review'}],o=>{DB.add('feedback',{order:id,who:me().name,stars:+o.stars,text:o.text});Notif.send('owner','New customer feedback');toast('Thanks for your feedback')})},
 mine(u){const o=DB.get('orders').filter(x=>x.cust==u.id).sort((a,b)=>b.t-a.t);
  return '<h3>My orders</h3>'+tbl(['Order','Items','Total','Type','Status',''],o.map(x=>[x.no+'<br><small>'+when(x.t)+'</small>',itemsTxt(x),money(x.pay.total),x.type,'<b>'+x.status+'</b>',btn('Bill',`Billing.print('${x.id}')`,'alt')+(x.status==ST[0]?btn('Cancel',`Orders.cancel('${x.id}')`,'danger'):'')+(x.status=='Completed'?btn('Rate',`Orders.rate('${x.id}')`):'')]))},
 staff(u){const ow=u.role=='owner',ch=DB.get('users').filter(x=>x.role=='chef'&&x.active);let o=DB.get('orders').sort((a,b)=>b.t-a.t);if(!ow)o=o.filter(x=>!x.chef||x.chef==u.id);
  return '<h3>'+(ow?'All orders':'Kitchen orders')+'</h3>'+tbl(['Order','Items','Total','Status','Chef','Actions'],o.map(x=>{let a=btn('Bill',`Billing.print('${x.id}')`,'alt');
   if(ow){if(x.status==ST[0])a+=btn('Accept',`Orders.set('${x.id}','Accepted')`)+btn('Reject',`Orders.set('${x.id}','Cancelled')`,'danger');a+=`<select onchange="Orders.set('${x.id}',this.value)">${ST.map(s=>`<option ${s==x.status?'selected':''}>${s}</option>`).join('')}</select>`}
   else{if(x.status=='Accepted')a+=btn('Start preparing',`Orders.set('${x.id}','Preparing')`);if(x.status=='Preparing')a+=btn('Mark ready',`Orders.set('${x.id}','Ready')`)}
   return [x.no+'<br><small>'+x.type+'</small>',itemsTxt(x),money(x.pay.total),'<b>'+x.status+'</b>',ow?`<select onchange="Orders.assign('${x.id}',this.value)"><option value="">—</option>${ch.map(c=>`<option value="${c.id}" ${c.id==x.chef?'selected':''}>${esc(c.name)}</option>`).join('')}</select>`:esc((DB.find('users',x.chef)||{name:'—'}).name),a]}))}
};
