# Future backend integration
Replace the DB methods in storage.js (get, set, find, add, upd, del) with fetch() calls (see the FUTURE API comments in each js file). Hash passwords and use tokens instead of the demo login in auth.js. Move notifications to websockets.
