# System architecture
Pages load the same JS modules. All reads/writes go through DB in storage.js (localStorage, key prefix ras_). The browser storage event re-renders other open tabs. Supplier can only create invoices; only the Owner's approval changes official stock.
