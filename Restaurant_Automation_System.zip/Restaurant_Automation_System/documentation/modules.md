# Modules
storage.js (data layer), auth.js, app.js (shell and helpers), menu.js, orders.js (cart + orders), inventory.js (stock, requests, invoices), notifications.js, billing.js, reports.js (overview, reports, employees).
