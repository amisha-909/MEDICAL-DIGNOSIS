# Features
Menu management, cart and orders with 7 statuses, notifications, inventory with low-stock alerts, supplier requests and invoices, billing with GST and discount, expenses, reports, feedback, activity history, employee management, reset demo data.
