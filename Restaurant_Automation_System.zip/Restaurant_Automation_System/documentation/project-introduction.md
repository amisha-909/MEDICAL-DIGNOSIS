# Project introduction
Frontend of a Restaurant Automation System for a B.Tech CSE project with four roles: Customer, Owner, Chef, Ingredient Supplier.
