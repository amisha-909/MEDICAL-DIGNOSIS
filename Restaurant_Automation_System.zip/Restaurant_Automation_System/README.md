# RESTAURANT AUTOMATION SYSTEM (frontend)
Frontend-only B.Tech project: HTML5, CSS3, vanilla JavaScript, localStorage. No paid tools. localStorage is TEMPORARY storage until a backend exists.

## Run (Ubuntu)
1. `unzip Restaurant_Automation_System.zip && cd Restaurant_Automation_System`
2. `python3 -m http.server 8000`
3. Open http://localhost:8000/frontend/index.html (or open frontend/index.html directly).

## Demo logins
owner@restaurant.com / owner123 · chef@restaurant.com / chef123 · supplier@restaurant.com / supplier123 · customer@restaurant.com / customer123

Tip: each browser tab keeps its own login, so open one tab per role and watch changes sync live. Owner > Overview has "Reset demo data".
Folders: frontend/ (pages), css/, js/ (storage.js is the only file touching localStorage), documentation/.
